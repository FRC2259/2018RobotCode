/* HOW TO DEPLOY
 * Right click on the project name (OptimusPrime)
 * GOTO the `Run As` sub-menu
 * Select `WPILib C++ Deploy`
 */

/* USEFUL DOCUMENTATION (add to this list as you find useful things)
 * WPILib docs: http://first.wpi.edu/FRC/roborio/release/docs/cpp/index.html
 * (look at Classes/Class List/frc)
 * FRC C++ Programming guide: C:\Users\cecrobotics\Desktop\FRC_C___Programming
 * Using the joysticks:jhjh http://wpilib.screenstepslive.com/s/3120/m/7912/l/133053-joysticks
 * TIMER DOCUMENTATION: (note getfpgatime) http://first.wpi.edu/FRC/roborio/release/docs/cpp/classfrc_1_1Timer.html#a5f16e8da27d2a5a5242dead46de05d97
 */

#include <iostream>//streams input/output
#include <memory>//dynamic memory management
#include <string>//WORDS!

#include <Timer.h>//timer stuff
#include <WPILib.h>//library robotics stuff
#include <IterativeRobot.h>//implements a specific type of Robot Program framework, extending the RobotBase class.
#include <LiveWindow/LiveWindow.h>
#include <SmartDashboard/SendableChooser.h>//uses dashboard stuff and things for bot
#include <SmartDashboard/SmartDashboard.h>//libraries for all sorts of stuff

// Autonomous Cases
#define LEFT_AND_LEFT    0
#define LEFT_AND_RIGHT   1
#define MIDDLE_AND_LEFT  2
#define MIDDLE_AND_RIGHT 3
#define RIGHT_AND_LEFT   4
#define RIGHT_AND_RIGHT  5

//time to lift all way up, CHANGE WHEN TESTED
#define LIFT_MAX_RESIST  720

class Robot:
	public frc::IterativeRobot {
		frc::Talon leftWheel;
		frc::Talon rightWheel;
		frc::DifferentialDrive drive;
		frc::Talon forkliftleft;
		frc::Talon forkliftright;
		frc::Talon clawL;
		frc::Talon clawR;
		frc::Talon liftClaw;
		frc::Joystick stickLeft {0};
		frc::Joystick stickRight {1};
		frc::Servo PlatDrop;
		int startGame;
		//frc::Timer shooterTimer;
		Potentiometer *pot;
		AnalogInput *ai;


		public:
			Robot(): //Order matters - this should match what's above
				leftWheel(0),
				rightWheel(1),
				drive(leftWheel, rightWheel),
				forkliftleft(2),
				forkliftright(3),
				clawL(4),
				clawR(5),
				liftClaw(6),
				PlatDrop(7){
					//CHANGE ACCORDING TO POSITION AT START OF GAME
					startGame = autonomousCase();
					//pot = new AnalogPotentiometer(0, 3600, 30);
					ai = new AnalogInput(0);
					pot = new AnalogPotentiometer(ai, 360, 30);
				}
				//shooterTimer(),

			void RobotInit() {
				chooser.AddDefault(autoNameDefault, autoNameDefault);
				chooser.AddObject(autoNameCustom, autoNameCustom);
				  CameraServer::GetInstance()->StartAutomaticCapture();
				frc::SmartDashboard::PutData("Auto Modes", &chooser);
			}

			/*
			 * This autonomous (along with the chooser code above) shows how to select
			 * between different autonomous modes using the dashboard. The sendable
			 * chooser code works with the Java SmartDashboard. If you prefer the
			 * LabVIEW Dashboard, remove all of the chooser code and uncomment the
			 * GetString line to get the auto name from the text box below the Gyro.
			 *
			 * You can add additional auto modes by adding additional comparisons to the
			 * if-else structure below with additional strings. If using the
			 * SendableChooser make sure to add them to the chooser code above as well.
			 */
			void AutonomousInit() override {
				//CHANGE ACCORDING TO POSITION AT START OF GAME
				startGame = autonomousCase();
			}

			void AutonomousPeriodic() {
				switch(startGame){
					case LEFT_AND_LEFT:
						drive.TankDrive(-0.5, -0.5, true);
						frc::Wait(1.0);
						drive.TankDrive(-0.0, -0.0, true);
						frc::Wait(1.0);
						//drive forward,
						drive.TankDrive(-0.5, -0.5, true);
						frc::Wait(4.0);
						//right turn
						drive.TankDrive(-0.5, 0.5, true);
						frc::Wait(1.0);
						//drive forward again
						drive.TankDrive(-0.5, -0.5, true);
						frc::Wait(2.0);
						//claw
						autonomousReleaseCube();
						break;
					case LEFT_AND_RIGHT:
						drive.TankDrive(-0.5, -0.5, true);
						frc::Wait(1.0);
						drive.TankDrive(-0.0, -0.0, true);
						frc::Wait(1.0);
						//Drive Forward
						drive.TankDrive(-0.5, -0.5, true);
						frc::Wait(8.0);
						//Right turn
						drive.TankDrive(-0.5, 0.5, true);
						frc::Wait(1.0);
						//Drive forward
						drive.TankDrive(-0.5, -0.5, true);
						frc::Wait(8.0);
						//Right turn
						drive.TankDrive(-0.5, 0.5, true);
						frc::Wait(1.0);
						//Drive forward
						drive.TankDrive(-0.5, -0.5, true);
						frc::Wait(1.0);
						//claw
						autonomousReleaseCube();
						break;
					case MIDDLE_AND_LEFT:
						drive.TankDrive(-0.5, -0.5, true);
						frc::Wait(1.0);
						drive.TankDrive(-0.0, -0.0, true);
						frc::Wait(1.0);
						//Drive Forward
						drive.TankDrive(-0.5, -0.5, true);
						frc::Wait(2.0);
						//Turn slightly left
						drive.TankDrive(0.5, -0.5, true);
						frc::Wait(0.5);
						//Drive
						drive.TankDrive(-0.5, -0.5, true);
						frc::Wait(1.0);
						//Turn slightly right
						drive.TankDrive(-0.5, 0.5, true);
						frc::Wait(0.5);
						//Drive
						drive.TankDrive(-0.5, -0.5, true);
						frc::Wait(1.0);
						//claw
						autonomousReleaseCube();
						break;

					case MIDDLE_AND_RIGHT:
						drive.TankDrive(-0.5, -0.5, true);
						frc::Wait(1.0);
						drive.TankDrive(-0.0, -0.0, true);
						frc::Wait(1.0);
						//Drive forward
						drive.TankDrive(-0.5, -0.5, true);
						frc::Wait(2.0);
						//turn  slightly right
						drive.TankDrive(-0.5, 0.5, true);
						frc::Wait(0.5);
						//forward
						drive.TankDrive(-0.5, -0.5, true);
						frc::Wait(1.0);
						//turn left
						drive.TankDrive(0.5, -0.5, true);
						frc::Wait(0.5);
						//drive
						drive.TankDrive(-0.5, -0.5, true);
						frc::Wait(1.0);
						//claw
						autonomousReleaseCube();
						break;

					case RIGHT_AND_LEFT:
						drive.TankDrive(-0.5, -0.5, true);
						frc::Wait(1.0);
						drive.TankDrive(-0.0, -0.0, true);
						frc::Wait(1.0);
						//drive forward, turn, drive forward, claw
						drive.TankDrive(-0.5, -0.5, true);
						frc::Wait(8.0);
						//left turn
						drive.TankDrive(0.5, -0.5, true);
						frc::Wait(1.0);
						//drive forward again
						drive.TankDrive(-0.5, -0.5, true);
						frc::Wait(8.0);
						//left turn
						drive.TankDrive(0.5, -0.5, true);
						frc::Wait(1.0);
						//drive forward
						drive.TankDrive(-0.5, -0.5, true);
						frc::Wait(1.0);
						//claw
						autonomousReleaseCube();
						break;

					case RIGHT_AND_RIGHT:
						drive.TankDrive(-0.5, -0.5, true);
						frc::Wait(1.0);
						drive.TankDrive(-0.0, -0.0, true);
						frc::Wait(1.0);
						//drive forward,
						drive.TankDrive(-0.5, -0.5, true);
						frc::Wait(4.0);
						//left turn
						drive.TankDrive(-0.5, 0.5, true);
						frc::Wait(1.0);
						//drive forward again
						drive.TankDrive(-0.5, -0.5, true);
						frc::Wait(2.0);
						//claw
						autonomousReleaseCube();
						break;

					default:
						frc::Wait(2.0);
				}
			}
			void TeleopInit() {

			}

			void TeleopPeriodic() {
				std::cout << pot->Get() << std::endl;
				drive.TankDrive(stickRight.GetY()/1.5,stickLeft.GetY()/1.5,false);
				////////Claw In///////
				if (stickRight.GetRawButton(1)) {
					this->clawR.Set(.40);
					this->clawL.Set(-.40);
				}
				////////Claw Out////////
				else if (stickLeft.GetRawButton(1)) {
					this->clawR.Set(-.40);
					this->clawL.Set(.40);
				}
				else{
					this->clawR.Set(0);
					this->clawL.Set(0);
				}

				///////drop lift///////
				if(stickRight.GetRawButton(3)){
					this->forkliftright.Set(0.40);
					this->forkliftleft.Set(-0.40);
				}
				///////lift Lift ///////
				else if(stickLeft.GetRawButton(3)){
					this->forkliftright.Set(-0.40);
					this->forkliftleft.Set(0.40);
				}
				///////send climber up///////
				else if (stickLeft.GetRawButton(2)){
					//teleOpClimb();
				}
				///////bring robot up to climber//////
				else if(stickRight.GetRawButton(2)){
					//teleOpLiftoff();
				}
				else {
					this->forkliftright.Set(.0);
					this->forkliftleft.Set(.0);
				}

				///////drop claw///////
				if(stickLeft.GetRawButton(5)){
					this->liftClaw.Set(.15);
				}
				///////lift claw///////
				else if(stickRight.GetRawButton(4)){
					this->liftClaw.Set(-.15);
				}
				else {
					this->liftClaw.Set(0.0);
				}
				///////PlatDrop///////
				if(stickLeft.GetRawButton(7)){
					this->PlatDrop.Set(2);
				}
				else {
					this->PlatDrop.Set(0);
				}
			}

		private:
			frc::LiveWindow* lw = LiveWindow::GetInstance();
			frc::SendableChooser<std::string> chooser;
			const std::string autoNameDefault = "Default";
			const std::string autoNameCustom = "My Auto";
			std::string autoSelected;

			int autonomousCase(){
				int gameDataStart = DriverStation::GetInstance().GetLocation();
				std::string gameDataSwitch;
				gameDataSwitch = DriverStation::GetInstance().GetGameSpecificMessage();

				//gameDataSwitch[0] == L -> Left Switch side, == R -> Right Switch side
				//gameDataStart == 1 -> Left, == 2 -> Middle, == 3 -> Right

				if(gameDataSwitch.length() > 0  && gameDataStart >= 0){
					if(gameDataSwitch[0] == 'L'){
						if(gameDataStart == 0){
							return LEFT_AND_LEFT;
						}
						else if(gameDataStart == 1){
							return MIDDLE_AND_LEFT;
						}
						else if(gameDataStart == 2){
							return RIGHT_AND_LEFT;
						}
					}
					else if(gameDataSwitch[0] == 'R'){
						if(gameDataStart == 0){
							return LEFT_AND_RIGHT;
						}
						else if(gameDataStart == 1){
							return MIDDLE_AND_RIGHT;
						}
						else if(gameDataStart == 2){
							return RIGHT_AND_RIGHT;
						}
					}
					else {
						return startGame;
					}
				}
				return startGame;
			}

			void teleOpClimb(){
				while(pot->Get() < LIFT_MAX_RESIST){
					this->forkliftright.Set(-.30);
					this->forkliftleft.Set(.30);
				}
			}
			void teleOpLiftoff(){
				while(pot->Get() > (-1) * LIFT_MAX_RESIST){
					this->forkliftright.Set(0.30);
					this->forkliftleft.Set(-.30);
				}
			}
			void autonomousReleaseCube(){
				//releases cube in auto mode
				while(pot->Get() < LIFT_MAX_RESIST/2){
					forkliftright.Set(-0.3);
					forkliftleft.Set(0.3);
				}
				//frc::Wait(LIFT_TIME_UP/2);

				clawL.Set(-0.5);
				clawR.Set(-0.5);
				frc::Wait(1.0);
			}
};

START_ROBOT_CLASS(Robot);


